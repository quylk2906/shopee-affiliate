const SHOPEE_URL = "https://affiliate.shopee.vn/api/";
const statusDot = document.querySelector("#status-dot");
const statusText = document.querySelector("#status-text");
const syncButton = document.querySelector("#sync-button");
const settingsButton = document.querySelector("#settings-button");
const resultMessage = document.querySelector("#result-message");
const resultIcon = document.querySelector("#result-icon");
const resultTitle = document.querySelector("#result-title");
const resultDetail = document.querySelector("#result-detail");
const lastSync = document.querySelector("#last-sync");
const lastSyncTime = document.querySelector("#last-sync-time");

function setStatus(message, state = "") {
  statusText.textContent = message;
  statusDot.className = `status-dot ${state}`.trim();
}

function hideResult() {
  resultMessage.hidden = true;
  resultMessage.className = "result-message";
  resultMessage.setAttribute("role", "status");
}

function showResult(type, title, detail) {
  resultMessage.hidden = false;
  resultMessage.className = `result-message ${type}`;
  resultMessage.setAttribute("role", type === "error" ? "alert" : "status");
  resultIcon.textContent = type === "success" ? "✓" : "!";
  resultTitle.textContent = title;
  resultDetail.textContent = detail;
}

function formatSyncTime(value) {
  const date = new Date(value);
  return Number.isNaN(date.getTime())
    ? ""
    : new Intl.DateTimeFormat(undefined, {
        dateStyle: "medium",
        timeStyle: "short",
      }).format(date);
}

function showLastSync(value) {
  const formatted = formatSyncTime(value);
  lastSync.hidden = !formatted;
  lastSyncTime.textContent = formatted;
}

function validateSettings(settings) {
  if (!settings.endpointUrl || !settings.syncSecret) {
    throw new Error("Open Settings to connect your Vercel app.");
  }

  const endpoint = new URL(settings.endpointUrl);
  const isLocalhost =
    endpoint.protocol === "http:" &&
    ["localhost", "127.0.0.1"].includes(endpoint.hostname);
  if (endpoint.protocol !== "https:" && !isLocalhost) {
    throw new Error("The endpoint must use HTTPS (or localhost).");
  }

  return endpoint;
}

function permissionPattern(endpoint) {
  return `${endpoint.protocol}//${endpoint.host}/*`;
}

async function ensureEndpointPermission(endpoint) {
  const origins = [permissionPattern(endpoint)];
  if (await chrome.permissions.contains({ origins })) return;

  const granted = await chrome.permissions.request({ origins });
  if (!granted) {
    throw new Error("Allow access to your Vercel app to continue.");
  }
}

async function activeCookieStoreId() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return undefined;

  const stores = await chrome.cookies.getAllCookieStores();
  return stores.find((store) => store.tabIds.includes(tab.id))?.id;
}

async function captureCookieHeader() {
  const storeId = await activeCookieStoreId();
  const details = storeId ? { url: SHOPEE_URL, storeId } : { url: SHOPEE_URL };
  const cookies = await chrome.cookies.getAll(details);

  if (cookies.length === 0) {
    throw new Error("No Shopee cookies found. Sign in, then try again.");
  }

  return {
    count: cookies.length,
    header: cookies.map(({ name, value }) => `${name}=${value}`).join("; "),
  };
}

async function syncCookies() {
  syncButton.disabled = true;
  hideResult();
  setStatus("Capturing cookies…", "working");

  try {
    const settings = await chrome.storage.local.get([
      "endpointUrl",
      "syncSecret",
    ]);
    const endpoint = validateSettings(settings);
    await ensureEndpointPermission(endpoint);

    const captured = await captureCookieHeader();
    setStatus(`Syncing ${captured.count} cookies…`, "working");

    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${settings.syncSecret}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ cookie: captured.header }),
      cache: "no-store",
    });

    const result = await response.json().catch(() => ({}));
    if (!response.ok) {
      throw new Error(
        typeof result.error === "string"
          ? result.error
          : `Sync failed (${response.status}).`,
      );
    }

    const syncedAt = new Date().toISOString();
    await chrome.storage.local.set({ lastSyncedAt: syncedAt });
    showLastSync(syncedAt);
    setStatus("Cookie synced securely", "success");
    showResult(
      "success",
      "Sync successful",
      `Updated ${result.key ?? "Global Config"} with ${captured.count} cookies.`,
    );
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Could not sync cookies.";
    setStatus("Sync failed", "error");
    showResult("error", "Sync failed", message);
  } finally {
    syncButton.disabled = false;
  }
}

async function initialize() {
  const settings = await chrome.storage.local.get([
    "endpointUrl",
    "syncSecret",
    "lastSyncedAt",
  ]);

  showLastSync(settings.lastSyncedAt);
  try {
    validateSettings(settings);
    setStatus("Ready to capture", "ready");
    syncButton.disabled = false;
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Settings required.";
    setStatus("Setup required", "error");
    showResult("error", "Setup required", message);
  }
}

syncButton.addEventListener("click", syncCookies);
settingsButton.addEventListener("click", () =>
  chrome.runtime.openOptionsPage(),
);
initialize();
